<div>
    <h2>Test page #2</h2>
    <p>This is a paragraph on the <b>SECOND TEST PAGE</b> inside of a section. This should fit well on any device wheter it be:</p>
    <ul>
        <li>Mobile</li>
        <li>Tablet</li>
        <li>Desktop</li>
    </ul>
    <h2>This is the second heading</h2>
    <p>This comes directly after the first. Click <a href="https://hexstudios.co/dev/wiki/index.php?page=test">HERE</a> to go to page 1 of this wiki.</p>
</div>