<div>
    <h2>Welcome to the Hex Studios Wiki</h2>
    <p>This wiki was developed by Hex Studios and is licensed under GPL-3.0. </p>
</div>