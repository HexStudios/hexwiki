<div>
    <h2>Test page</h2>
    <p>This is a paragraph on the tet page inside of a section. This should fit well on any device wheter it be:</p>
    <ul>
        <li>Mobile</li>
        <li>Tablet</li>
        <li>Desktop</li>
    </ul>
    <h2>This is the second heading</h2>
    <p>This comes directly after the first. Click <a href="https://hexstudios.co/dev/wiki/index.php?page=test2">HERE</a> to go to page 2 of this wiki.</p>
</div>